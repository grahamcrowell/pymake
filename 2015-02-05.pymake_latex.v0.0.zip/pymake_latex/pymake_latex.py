__author__ = 'grahamcrowell'

# /Users/grahamcrowell/Dropbox/DOCS/eclipse_workspace/pymake_latex/test_script.command
# /Users/grahamcrowell/Dropbox/DOCS/eclipse_workspace/pymake_latex/

import os, sys, string, itertools, shutil, inspect, subprocess, time

_latex_main_name = 'main.tex'
_input_line = '--------------------------------------------------------------------'
_input_cmd_format = lambda latex_src: '\t\\input{' + '{}'.format(latex_src) + '}\n'
_biblio_cmd = '\\bibliography{'
_esc_seq_latex = '%'

_config_name = 'pymake.config'
_esc_seq_config = '//'

def show_splash():
    print('\n\npymake_latex building latex project\n\n')

def parse_param_line(line):
    if __debug__:
        print('parsing parameter line:\n\t{}'.format(line))
    if isinstance(line, str) and '=' in line:
        line = string.strip(line)
        esc_pos = string.find(line, _esc_seq_config)
        if esc_pos > -1:
            if __debug__:
                print('line contains _esc_seq_config (esc_pos at: {})\n\tnew line: {}'.format(esc_pos, line[0:esc_pos]))
                line = line[0:esc_pos]
            return parse_param_line(line[0:esc_pos])
        elif '=' in line:
            key = string.strip(line.split('=')[0])
            val = string.strip(line.split('=')[1])
            if val[0:2] == './':
                val = os.path.join(os.path.split(sys.argv[0])[0], val[2:])
            if __debug__:
                print('valid parameter: {}={}'.format(key, val))
            return key, val
        else:
            return False
    else:
        return False

class Parameter(dict):
    def __init__(self, path):
        dict.__init__(self)
        self.path = os.path.normpath(path)
        assert(os.path.isfile(path))
        with open(path) as param_file:
            self.update(dict(map(parse_param_line, itertools.ifilter(parse_param_line, param_file.readlines()))))



def create_bib(params, bib_path):
    if os.path.isfile(bib_path):
        return 
    message = '\t\t!!!copying template {}!!!'.format(param_dict['bib_template'])
    if os.path.split(bib_path)[1] != param_dict['bib_template']:
        message += ' (as {})'.format(os.path.split(bib_path)[1])
    print(message)
    bib_template_path = os.path.join(param_dict['latex_template_dir'], param_dict['bib_template'])
    assert os.path.isfile(bib_template_path)
    shutil.copyfile(bib_template_path, bib_path)

def detect_biblio(params, project_main):
    with open(project_main) as main_file:
        lines = main_file.readlines()
        bib_lines = list(itertools.ifilter(lambda line: _biblio_cmd in line, lines))
    if len(bib_lines) == 0:
        return False
    else:
        bib_line = bib_lines[0]
#     print(bib_line)
    esc_pos = string.find(bib_line, _esc_seq_latex)
#     print('esc_pos = {}'.format(esc_pos))
    bib_cmd_pos = string.find(bib_line, _biblio_cmd)
#     print('bib_cmd_pos = {}'.format(bib_cmd_pos))
    if esc_pos > -1 and esc_pos < bib_cmd_pos:
        return False
    else:
        bib_file_pos = bib_cmd_pos + len(_biblio_cmd)
        bib_file_len = string.find(bib_line[bib_file_pos:], '}')
        bib_name = bib_line[bib_file_pos:bib_file_pos + bib_file_len]
        if os.path.splitext(bib_name)[1].lower() != '.bib':
            bib_name = bib_name + '.bib'
            bib_path = os.path.join(project_dir, bib_name)
            print('\tbibTeX execution required (ref file: {}). . .'.format(os.path.split(bib_path)[1]))
            if not os.path.isfile(bib_path):
                create_bib(params, bib_path)
            else:
                print('\t\t{} found'.format(os.path.split(bib_path)[1]))
        return True

def execute(cmd):
    print('!!!executing:\n\t{}!!!'.format(cmd))
    p = subprocess.Popen(cmd, shell=True, stderr=subprocess.PIPE)
    
    c = time.clock()
    
    while True:
        out = p.stderr.read(1)
        if out == '' and p.poll() != None:
            print('process execution complete')
            break
        if out != '':
            sys.stdout.write(out)
            sys.stdout.flush()

def quiet_execute(cmd):
    print('!!!quietly executing:\n\t{}!!!'.format(cmd))
    p = subprocess.Popen(cmd, shell=True, stderr=subprocess.PIPE, stdin=subprocess.PIPE)
    p.wait()
#     
#     c = time.clock()
#     
#     while True:
#         out = p.stderr.read(1)
#         if out == '' and p.poll() != None:
#             print('process execution complete')
#             break
#         if out != '':
#             sys.stdout.write(out)
#             sys.stdout.flush()
            


def preview(params, pdf_path):
    print('!!!previewing!!!')
    cmd = '"open -a /Applications/Preview.app {}"'.format(pdf_path)
    cmd = 'open "{}"'.format(pdf_path)
    cmd = '/usr/bin/qlmanage -p "{}"'.format(pdf_path)
    args = ['/usr/bin/qlmanage', ' -p ' , '"{}"'.format(pdf_path)]
#     subprocess.call(cmd)
    quiet_execute(cmd)

def delete_files(directory, exts=['.aux', '.log', '.out']):
    assert os.path.isdir(directory)
    del_files = list(itertools.ifilter(lambda filename: os.path.splitext(filename)[1] in exts, os.listdir(directory)))
    map(os.remove, del_files)
    
def typeset(params, project_main):
    print('!!!typesetting!!!')
    project_dir = os.path.split(project_main)[0]
    job_name = os.path.split(project_dir)[1]
    pdf_filename = os.path.join(project_dir,job_name+'.pdf')
    if params['tex_bin_dir'] == '':
        pdflatex_cmd = 'pdflatex'
    else:
        pdflatex_cmd = os.path.join(params['tex_bin_dir'], 'pdflatex')
    pdflatex_cmd += ' -output-directory "{}" -jobname "{}" "{}"'.format(project_dir, job_name, project_main);
    print('pdflatex_cmd = {}'.format(pdflatex_cmd))
    execute(pdflatex_cmd)
    is_bib = detect_biblio(params, project_main)
    if is_bib:
        pass
    
    delete_files(project_dir)
    return pdf_filename


def create_main(params, latex_src_path):
    project_dir = os.path.split(latex_src)[0]
    project_main = os.path.join(project_dir, _latex_main_name)
    latex_template_path = os.path.join(param_dict['latex_template_dir'], param_dict['latex_template_std'])
    assert os.path.isfile(latex_template_path)
    with open(latex_template_path) as template_file:
        lines = template_file.readlines()
        with open(project_main, 'w') as main_file:
            for line in lines:
                main_file.write(line)
                if _input_line in line:
                    latex_src_name = os.path.split(latex_src_path)[1]
                    main_file.write(_input_cmd_format(latex_src_name))
    
# def copy_main(param_dict, latex_file):
#     latex_template_path = os.path.join(param_dict['latex_template_dir'], param_dict['latex_template_std'])
#     if __debug__:
#         print(param_dict)
#     assert os.path.isfile(latex_template_path)
#     if os.path.isfile(latex_file):
#         project_dir = os.path.split(latex_file)[0]
#     elif latex_file is None:
#         assert os.path.isdir(project_dir)
#         
#         pass
#         # TODO: search directory project_dir for *.tex files
#         print('\n\n************************\n\nNO LATEX SOURCE FILE GIVEN\n\n************************\n\tdirectory search not implimented\n\tdir: {}\n\n'.format(project_dir))
#         raise NotImplementedError()
#     main_path = os.path.join(project_dir, 'main.tex')
#     print(main_path)
#     if os.path.isfile(main_path):
#         if __debug__:
#             print('main.tex exists')
#     else:
#         if __debug__:
#             print('copying:\nsrc\n\t{}\ndest\n\t{}'.format(latex_template_path, main_path))
#         # COPY template as main.tex
#         shutil.copyfile(latex_template_path, main_path)
        
if __name__ == '__main__':
    show_splash()
#     pymake_dir = os.path.split(inspect.getframeinfo(inspect.currentframe()).filename)[0]
    pymake_dir = os.path.split(sys.argv[0])[0]
    config_path = os.path.join(pymake_dir, _config_name)
    if __debug__:
        print('sys.argv: {}'.format(sys.argv))
        print('os.getcwd(): {}'.format(os.getcwd()))
    param_dict = Parameter(config_path)
    if __debug__:
        print(param_dict)
    if len(sys.argv) == 1:
        project_dir = os.getcwd()
        project_main = os.path.join(project_dir, _latex_main_name)
        assert os.path.isfile(project_main)
    else:
        
        if os.path.isfile(sys.argv[1]):
            latex_src = sys.argv[1]
            project_dir = os.path.split(latex_src)[0]
            assert os.path.splitext(latex_src)[1].lower() == '.tex'
            project_main = os.path.join(project_dir, _latex_main_name)
            if not os.path.isfile(project_main):
                create_main(param_dict, latex_src)
            assert os.path.isfile(project_main)
        elif os.path.isdir(sys.argv[1]):
            project_dir = sys.argv[1]
            project_main = os.path.join(project_dir, _latex_main_name)
            assert os.path.isfile(project_main)
        else:
            # received filename but no path
            project_dir = os.getcwd()
            latex_src = os.path.join(project_dir, sys.argv[1])
            assert os.path.isfile(latex_src)
            project_main = os.path.join(project_dir, _latex_main_name)
            if not os.path.isfile(project_main):
                create_main(param_dict, latex_src)
            assert os.path.isfile(project_main)
    pdf_filename = typeset(param_dict, project_main)
    
    preview(param_dict, pdf_filename)
