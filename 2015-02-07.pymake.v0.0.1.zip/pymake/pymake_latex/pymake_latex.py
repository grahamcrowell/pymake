__author__ = 'grahamcrowell'

"""
this script recieves fullpath of a latex file, or latex project folder


Mac OSX sublime text 2: build-system:
    /Users/grahamcrowell/Library/Application\ Support/Sublime\ Text\ 2/Packages/User/latex.sublime-build 
    {
        "cmd": ["python", "-O", "/Users/grahamcrowell/Dropbox/pymake/pymake_latex/pymake_latex.py", "$file"],
        "working_dir": "${project_path:${folder}}",
        "selector": "source.latex"
    }
"""



import os, sys, string, itertools, shutil, inspect, subprocess, time, traceback

_latex_main_name = 'main.tex'
_input_line = '--------------------------------------------------------------------'
_input_cmd_format = lambda latex_src: '\t\\input{' + '{}'.format(latex_src) + '}\n'
_biblio_cmd = '\\bibliography{'
_esc_seq_latex = '%'

_config_name = 'pymake.config'
_esc_seq_config = '//'

def show_splash():
    print('\n\npymake_latex building latex project\n\n')

def parse_param_line(line):
    if __debug__:
        print('parsing parameter line:\n\t{}'.format(line))
    if isinstance(line, str) and '=' in line:
        line = string.strip(line)
        esc_pos = string.find(line, _esc_seq_config)
        if esc_pos > -1:
            if __debug__:
                print('line contains _esc_seq_config (esc_pos at: {})\n\tnew line: {}'.format(esc_pos, line[0:esc_pos]))
                line = line[0:esc_pos]
            return parse_param_line(line[0:esc_pos])
        elif '=' in line:
            key = string.strip(line.split('=')[0])
            val = string.strip(line.split('=')[1])
            if val[0:2] == './':
                val = os.path.join(os.path.split(sys.argv[0])[0], val[2:])
            if __debug__:
                print('valid parameter: {}={}'.format(key, val))
            return key, val
        else:
            return False
    else:
        return False

class Parameter(dict):
    def __init__(self, path):
        dict.__init__(self)
        self.path = os.path.normpath(path)
        assert(os.path.isfile(path))
        with open(path) as param_file:
            self.update(dict(map(parse_param_line, itertools.ifilter(parse_param_line, param_file.readlines()))))



def create_bib(params, bib_path):
    if os.path.isfile(bib_path):
        return 
    message = '\t\t!!!copying template {}!!!'.format(param_dict['bib_template'])
    if os.path.split(bib_path)[1] != param_dict['bib_template']:
        message += ' (as {})'.format(os.path.split(bib_path)[1])
    print(message)
    bib_template_path = os.path.join(param_dict['latex_template_dir'], param_dict['bib_template'])
    assert os.path.isfile(bib_template_path)
    shutil.copyfile(bib_template_path, bib_path)

def detect_biblio(params, project_main):
    with open(project_main) as main_file:
        lines = main_file.readlines()
        bib_lines = list(itertools.ifilter(lambda line: _biblio_cmd in line, lines))
    if len(bib_lines) == 0:
        return False
    else:
        bib_line = bib_lines[0]
#     print(bib_line)
    esc_pos = string.find(bib_line, _esc_seq_latex)
#     print('esc_pos = {}'.format(esc_pos))
    bib_cmd_pos = string.find(bib_line, _biblio_cmd)
#     print('bib_cmd_pos = {}'.format(bib_cmd_pos))
    if esc_pos > -1 and esc_pos < bib_cmd_pos:
        return False
    else:
        bib_file_pos = bib_cmd_pos + len(_biblio_cmd)
        bib_file_len = string.find(bib_line[bib_file_pos:], '}')
        bib_name = bib_line[bib_file_pos:bib_file_pos + bib_file_len]
        if os.path.splitext(bib_name)[1].lower() != '.bib':
            bib_name = bib_name + '.bib'
            bib_path = os.path.join(project_dir, bib_name)
            if __debug__:
                print('\tbibTeX execution required (ref file: {}). . .'.format(os.path.split(bib_path)[1]))
            if not os.path.isfile(bib_path):
                create_bib(params, bib_path)
            else:
                if __debug__:
                    print('\t\t{} found'.format(os.path.split(bib_path)[1]))
        return True

def execute(cmd):

    if __debug__:
        print('!!!executing:\n\t{}!!!'.format(cmd))
    p = subprocess.Popen(cmd, shell=True, stderr=subprocess.PIPE)
    
    # c = time.clock()
    
    while True:
        out = p.stderr.read(1)
        if out == '' and p.poll() != None:
            if __debug__:
                print('process execution complete')
            break
        if out != '':
            sys.stdout.write(out)
            sys.stdout.flush()
    ret_code = p.wait()
    if ret_code != 0:
        raise Exception()
    else:
        return ret_code
    # print('\n\n\n\treturn code: {}\n\n\n'.format(ret_code))

def quiet_execute(cmd):
    if __debug__:
        print('!!!quietly executing:\n\t{}!!!'.format(cmd))
    p = subprocess.Popen(cmd, shell=True, stderr=subprocess.PIPE, stdin=subprocess.PIPE)
    ret_code = p.wait()
    if ret_code != 0:
        raise Exception()
    else:
        return ret_code

def fast_execute(cmd):
    if __debug__:
        print('!!!quietly executing:\n\t{}!!!'.format(cmd))
    p = subprocess.Popen(cmd)
    # ret_code = p.wait()
    if ret_code != 0:
        raise Exception()
    else:
        return ret_code

def preview(params, pdf_path):
    if __debug__:
        print('!!!previewing!!!')
    cmd = '"open -a /Applications/Preview.app {}"'.format(pdf_path)
    cmd = 'open "{}"'.format(pdf_path)
    cmd = '/usr/bin/qlmanage -p "{}"'.format(pdf_path)
    args = ['/usr/bin/qlmanage', ' -p ' , '"{}"'.format(pdf_path)]
#     subprocess.call(cmd)
    quiet_execute(cmd)

def delete_files(directory, exts=['.aux', '.log', '.out']):
    if __debug__:
        print('\n\nCLEANING PROJECT DIRECTORY\n\n')
    assert os.path.isdir(directory)

    del_names = list(itertools.ifilter(lambda filename: os.path.splitext(filename)[1] in exts, os.listdir(directory)))
    del_paths = map(lambda del_name: os.path.join(directory,del_name), del_names)
    if __debug__:
        print('\n\n\n\t****\nfiles to be deleted:\n\t{}\n\n'.format(del_names))
    map(os.remove, del_paths)
    
def typeset(params, project_main):
    if __debug__:
        print('!!!typesetting!!!')
    project_dir = os.path.split(project_main)[0]
    job_name = os.path.split(project_dir)[1]
    pdf_filename = os.path.join(project_dir,job_name+'.pdf')
    if params['tex_bin_dir'] == '':
        pdflatex_cmd = 'pdflatex'
    else:
        pdflatex_cmd = os.path.join(params['tex_bin_dir'], 'pdflatex')
    pdflatex_cmd += '  -halt-on-error -output-directory "{}" -jobname "{}" "{}"'.format(project_dir, job_name, project_main);
    if __debug__:
        print('pdflatex_cmd = {}'.format(pdflatex_cmd))
    
    execute(pdflatex_cmd)

    is_bib = detect_biblio(params, project_main)
    if is_bib:
        raise NotImplementError()
    
    
    return pdf_filename


def create_main(params, latex_src_path):
    project_dir = os.path.split(latex_src)[0]
    project_main = os.path.join(project_dir, _latex_main_name)
    latex_template_path = os.path.join(param_dict['latex_template_dir'], param_dict['latex_template_std'])
    assert os.path.isfile(latex_template_path)
    with open(latex_template_path) as template_file:
        lines = template_file.readlines()
        with open(project_main, 'w') as main_file:
            for line in lines:
                main_file.write(line)
                if _input_line in line:
                    latex_src_name = os.path.split(latex_src_path)[1]
                    main_file.write(_input_cmd_format(latex_src_name))

def handle_cmd_args():
    """ parse command line arguments for latex project return dict Parameter, path project_main """
#     pymake_dir = os.path.split(inspect.getframeinfo(inspect.currentframe()).filename)[0]
    pymake_dir = os.path.split(sys.argv[0])[0]
    config_path = os.path.join(pymake_dir, _config_name)
    if __debug__:
        print('sys.argv: {}'.format(sys.argv))
        print('os.getcwd(): {}'.format(os.getcwd()))
    param_dict = Parameter(config_path)
    if __debug__:
        print(param_dict)
    if len(sys.argv) == 1:
        project_dir = os.getcwd()
        project_main = os.path.join(project_dir, _latex_main_name)
        assert os.path.isfile(project_main)
    else:
        if os.path.isfile(sys.argv[1]):
            latex_src = sys.argv[1]
            project_dir = os.path.split(latex_src)[0]
            assert os.path.splitext(latex_src)[1].lower() == '.tex'
            project_main = os.path.join(project_dir, _latex_main_name)
            if not os.path.isfile(project_main):
                create_main(param_dict, latex_src)
            assert os.path.isfile(project_main)
        elif os.path.isdir(sys.argv[1]):
            project_dir = sys.argv[1]
            project_main = os.path.join(project_dir, _latex_main_name)
            assert os.path.isfile(project_main)
        else:
            # received filename but no path
            project_dir = os.getcwd()
            latex_src = os.path.join(project_dir, sys.argv[1])
            assert os.path.isfile(latex_src)
            project_main = os.path.join(project_dir, _latex_main_name)
            if not os.path.isfile(project_main):
                create_main(param_dict, latex_src)
            assert os.path.isfile(project_main)
    return param_dict, project_main

def build_latex_project():
    # try:
    param_dict, project_main = handle_cmd_args()
    pdf_filename = typeset(param_dict, project_main)
    preview(param_dict, pdf_filename)
    delete_files(os.path.split(project_main)[0])
    # except Exception as exception:
        # print('\n\n\tERROR BUILDING LATEX PROJECT\n')
        # print(exception)
        
if __name__ == '__main__':
    show_splash()
    try:
        build_latex_project()
    except Exception:
        ex_type, ex, tb = sys.exc_info()
        # print(ex_type)
        # print(type(ex_type))
        # print(ex)
        # print(type(ex))
        # print(tb)
        # print(type(tb))
        tb_lines = traceback.format_tb(tb)
        for line in tb_lines:
            print(line)
